link: 

https://c7d9-73-126-198-247.ngrok-free.app/Amilineni-MahendraVardhan_hw3_secondPhaseOfApp/

this is the external link for my page and the data is being stored at backend those screen shots are included in the folder.
