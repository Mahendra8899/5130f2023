<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "iwsphase2"; 

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $firstName = $_POST["firstname"];
    $lastName = $_POST["lastname"];
    $currentLocation = $_POST["currentlocation"];
    $desiredLocation = $_POST["desiredlocation"];
    $phoneNo = $_POST["phoneno"];
    $email = $_POST["email"];
    $whereilivenow = $_POST["whereilivenow"];
    $familyLocation = $_POST["familylocation"];
    $siblings = $_POST["siblings"];
    $siblingsBirthPlace = $_POST["siblingsbirthplace"];
    $preferredResidence = $_POST["dreamresidence"];
    $occupation = $_POST["occupation"];
    $factsAboutMe = $_POST["factsaboutyou"];
    $uploadfile = $_POST["uploadafile"];


    // Insert data to db
    $sql = "INSERT INTO aboutyou (firstname, lastname, currentlocation, desiredlocation, phoneno, email, whereilivenow, familylocation, siblings, siblingsbirthplace, dreamresidence, occupation, factsaboutyou,uploadafile)
            VALUES (
                '$firstName',
                '$lastName',
                '$currentLocation',
                '$desiredLocation',
                '$phoneNo',
                '$email',
                '$whereilivenow',
                '$familyLocation',
                '$siblings',
                '$siblingsBirthPlace',
                '$preferredResidence',
                '$occupation',
                '$factsAboutMe',
                '$uploadfile')";

    if ($conn->query($sql) === TRUE) {
        echo "Form data has been successfully submitted and saved to the database.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
