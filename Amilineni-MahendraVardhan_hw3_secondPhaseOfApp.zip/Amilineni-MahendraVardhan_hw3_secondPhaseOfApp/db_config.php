<?php
// Enabling error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "Starting script...<br>";

$host = 'localhost';
$db   = 'iwsphase2';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    echo "Trying to connect to DB...<br>";
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        echo "Processing POST data...<br>";

        // Using filter_input to sanitize input
        $firstName = filter_input(INPUT_POST, "FirstName", FILTER_SANITIZE_STRING);
        $lastName = filter_input(INPUT_POST, "LastName", FILTER_SANITIZE_STRING);
        $currentLocation = filter_input(INPUT_POST, "current_location", FILTER_SANITIZE_STRING);
        $desiredLocation = filter_input(INPUT_POST, "desired_location", FILTER_SANITIZE_STRING);
        $phoneNo = filter_input(INPUT_POST, "phone_no", FILTER_SANITIZE_STRING);  // fixed the key
        $email = filter_input(INPUT_POST, "email", FILTER_VALIDATE_EMAIL);
        $birthPlace = filter_input(INPUT_POST, "birth_place", FILTER_SANITIZE_STRING);  // fixed the key
        $currentResidence = filter_input(INPUT_POST, "current_residence", FILTER_SANITIZE_STRING);  // fixed the key
        $familyLocation = filter_input(INPUT_POST, "family_location", FILTER_SANITIZE_STRING);  // fixed the key
        $siblings = filter_input(INPUT_POST, "siblings", FILTER_SANITIZE_STRING);
        $siblingsBirthPlace = filter_input(INPUT_POST, "siblings_birth_place", FILTER_SANITIZE_STRING);  // fixed the key
        $preferredResidence = filter_input(INPUT_POST, "preferred_residence", FILTER_SANITIZE_STRING);  // fixed the key
        $occupation = filter_input(INPUT_POST, "occupation", FILTER_SANITIZE_STRING);
        $factsAboutMe = filter_input(INPUT_POST, "facts_about_me", FILTER_SANITIZE_STRING);  // fixed the key

        echo "Preparing SQL statement...<br>";

        $stmt = $pdo->prepare("INSERT INTO user_info 
            (FirstName, LastName, current_location, desired_location, phone_no, email, birth_place, current_residence, 
            family_location, siblings, siblings_birth_place, preferred_residence, occupation, facts_about_me)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->execute([$firstName, $lastName, $currentLocation, $desiredLocation, $phoneNo, $email, $birthPlace,
                        $currentResidence, $familyLocation, $siblings, $siblingsBirthPlace, $preferredResidence,
                        $occupation, $factsAboutMe]);

        echo "Data inserted successfully!<br>";

    } else {
        echo "Not a POST request...<br>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}

echo "Script ended.<br>";
?>
