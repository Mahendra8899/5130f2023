document.getElementById('homeButton').addEventListener('click', function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
