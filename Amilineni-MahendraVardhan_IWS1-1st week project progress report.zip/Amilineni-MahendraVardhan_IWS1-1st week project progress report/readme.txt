
Weekly Progress 1:

> We have created the landing page for our project and included necessary buttons.
> We started gathering the information related to this.
> We took some reference documents  for styling form w3 schools.

References:

1. https://www.w3schools.com/jsref/dom_obj_document.asp.
2. https://www.w3schools.com/js/js_htmldom.asp