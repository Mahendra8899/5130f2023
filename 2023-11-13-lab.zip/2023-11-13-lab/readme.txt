Please use google authenticator app to scan the qr and generate otp to sign in.
It will run on local host
The data will be saved to userDatabase.json file .

1. npm install 
2. node app.js
include all files together